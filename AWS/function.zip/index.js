var mysql = require('mysql');
var connection = mysql.createConnection({
    host     : 'database-2.c4scttzqkh9m.us-east-1.rds.amazonaws.com',
    user     : 'admin',
    password : 'gYeiEu8w43BhnSDuDp9Q',
    database : 'elevate',
    multipleStatements: true
});
 
// console.log(connection);
exports.handler = (event, context, callback) => {

var connection = mysql.createConnection({
    host     : 'database-2.c4scttzqkh9m.us-east-1.rds.amazonaws.com',
    user     : 'admin',
    password : 'gYeiEu8w43BhnSDuDp9Q',
    database : 'elevate'
});

    connection.connect();
    if (event.type == "profile"){
    	connection.query('select * from profile where id=' + event.id, function (error, results, fields) {
        	if (error) {
            	//connection.end();
            	console.log(error);
        	} else {
            	// connected!
            	//console.log(results);
            	callback(error, results);
	    	connection.end();
            	//connection.end(function (err) { callback(err, results);});
        	}	
    	});
    }
    else if (event.type == "transaction"){
        connection.query('insert into transaction (profile_id, vendor_id, amount, date) values (' + event.profile_id + ',' + event.vendor_id + ',' + event.amount + ',' + Date.now() + ');', function (error, results, fields) {
                if (error) {
                //connection.end();
                console.log(error);
                } else {
                // connected!
                console.log(results);
                //console.log(balance);
                callback(error, results);
                connection.end();
                //connection.end(function (err) { callback(err, results);});
                }
        });
    }

    else if (event.type == "balance_update"){
        connection.query('update profile set balance = (balance - ' + event.amount + ') where id = ' + event.profile_id + ';', function (error, results, fields) {
                if (error) {
                //connection.end();
                console.log(error);
                } else {
                // connected!
                //console.log(results);
                callback(error, results);
                connection.end();
                //connection.end(function (err) { callback(err, results);});
                }
        });
    }

    else if (event.type == "transaction_list"){
        connection.query('select profile.name as profile_name, vendor.name as vendor_name, transaction.amount, transaction.date from transaction join profile on transaction.profile_id = profile.id join vendor on transaction.vendor_id = vendor.id order by date desc;' , function (error, results, fields) {
                if (error) {
                //connection.end();
                console.log(error);
                } else {
                // connected!
                //console.log(results);
                callback(error, results);
                connection.end();
                //connection.end(function (err) { callback(err, results);});
                }
        });
    }   
  
};
